<?php include 'session.php'; ?>
<?php include 'public/menubar.php'; ?>
<?php include 'public/settings-form.php'; ?>
<?php include 'public/footer.php'; ?>